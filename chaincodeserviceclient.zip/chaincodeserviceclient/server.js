const express = require('express');
const fileUpload = require('express-fileupload');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
let fileBuffer;
// enable files upload
app.use(fileUpload({
    createParentPath: true
}));
const fs = require('fs');
const ipfsClient = require('ipfs-http-client');

//const ClientServiceRequest = require('../clientservicecc_new/lib/clientservicerequest');
const ipfs = new ipfsClient({host:'localhost',port:'5001',protocol:'http'});
const ipfs1 = new ipfsClient({host:'localhost',port:'5002',protocol:'http'});
//add other middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


const clientservicerequest = require('./services/createClientServiceRequest');
const requestdetails = require('./services/createRequestDetails');
const chatdetails = require('./services/createChat');
const chathistory = require('./services/createChatHistory');
//start app 
const port = process.env.PORT || 4000;


app.post('/createClientServiceRequest',async(req,res) => {

  try{
    //main("12345", "Issue", "BG","Subjecton Guarantee","Request for Guarantee product" );
    //requestId,issue_type,product,subject,description
    clientservicerequest.createClientServiceRequest(req.requestId, req.issue_type, req.product,req.subject,req.description);
  }catch(error){
    res.status(500).send(err);
  }
})


app.post('/createRequestDetails',async(req,res) => {

  try{
    //main("12345", "Issue", "BG","Subjecton Guarantee","Request for Guarantee product" );
    //requestId,request_name,Organisation,status,request_type,createdByUserId,timestamp
    requestdetails.createRequestDetails(req.requestId,req.request_name,req.Organisation,req.status,req.request_type,req.createdByUserId,Date.now);
  }catch(error){
    res.status(500).send(err);
  }
})


app.post('/createChat',async(req,res) => {

  try{
    //main("12345", "Issue", "BG","Subjecton Guarantee","Request for Guarantee product" );
    //room_name,room_id,userId,userName
    chatdetails.createChat(req.room_name,req.room_id,req.userId,req.userName);
  }catch(error){
    res.status(500).send(err);
  }
})

app.post('/createChatHistory',async(req,res) => {

  try{
    //main("12345", "Issue", "BG","Subjecton Guarantee","Request for Guarantee product" );
    //room_id,userID,message,timestamp
    chathistory.createChatHistory(req.room_id,req.userID,req.message,Date.now());
  }catch(error){
    res.status(500).send(err);
  }
})


app.post('/upload-avatar', async (req, res) => {
  try {
     console.log("req.file",req.files);
     if(!req.files) {
        res.send({
            status: false,
            message: 'No file uploaded'
        });
      } else {
          //Use the name of the input field (i.e. "avatar") to retrieve the uploaded file
          let avatar = req.files.avatar;
          console.log("avatar ",avatar);
          //Use the mv() method to place the file in upload directory (i.e. "uploads")
          
          iwrite(avatar.data).then(function(res,err){
            if(res){
              console.log("res ",res);
              //call read only after write is successful
              iread(res.path).then(function(res,err){
                if(res){
                  console.log("res in iread ",res);
                }
                if(err){
                  console.log("err in iread ",err);
                }
              })
            }
            if(err){
              console.log("err ",err);
            }
          });
         // avatar.mv('./uploads/' + avatar.name);

         
          //send response
          res.send({
              status: true,
              message: 'File is uploaded',
              data: {
                  name: avatar.name,
                  mimetype: avatar.mimetype,
                  size: avatar.size
              }
          });
      }
  } catch (err) {
      res.status(500).send(err);
  }
});
async function iwrite (file) {
  try{
    const results = await ipfs.add(file);
    //console.log(filepath);
    console.log('results', results);
    return results;
  }catch (error) {
      console.error(`Failed to write: ${error}`);
  }
}	

async function iread (docHash) {
  try{
      const invfile = await ipfs1.get(docHash);
      const currentDir = process.cwd();
      console.log("invfile ",invfile," currentDir ",currentDir);
      let chunks =[];
      for await (const file of ipfs1.get(docHash)) {
        console.log("...............",file.path);
        
        for await (const chunk of file.content) {
          chunks.push(chunk);
        }
        fileBuffer = Buffer.concat(chunks);
        var url = currentDir+'/'+docHash+'.svg';	
        var writeStream = fs.createWriteStream(url);
        writeStream.write(fileBuffer.toString('utf8'));
        writeStream.end();
      
        //console.log(content.toString())
      }

  }catch(error){
      console.log(error);
  }
}

app.listen(port, function(){
  console.log(`listening on *:${port}`);
});