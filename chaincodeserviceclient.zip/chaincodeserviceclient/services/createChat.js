/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
*/

/*
 * This application has 6 basic steps:
 * 1. Select an identity from a wallet
 * 2. Connect to network gateway
 * 3. Access PaperNet network
 * 4. Construct request to issue commercial paper
 * 5. Submit transaction
 * 6. Process response
 */

'use strict';

// Bring key classes into scope, most importantly Fabric SDK network class
const fs = require('fs');
const yaml = require('js-yaml');
const { getNetwork, disconnect } = require('../util/networkutil');
// Main program function
async function main(room_name,room_id,userId,userName) {

    try {
       //const contract = await getContractInstance();
       const contract = getNetwork().getContract('ChatContract');
        console.log('Submit Contact creation transaction.');
    
        const chatBuffer = await contract.submitTransaction("createChat",room_name,room_id,userId,userName);
        
        let newChat = JSON.parse(chatBuffer.toString());
        console.log(`${newChat.room_name}  successfully created`);
        console.log('Transaction complete.');
        return newChat;
    } catch (error) {
        console.log(`Error processing transaction. ${error}`);
        console.log(error.stack);
    } finally {
        // Disconnect from the gateway
        console.log('Disconnect from Fabric gateway.');
        disconnect();
    }
}


module.exports = {
    createChat: async function (room_name,room_id,userId,userName) {

    try {
       //const contract = await getContractInstance();
       const network = await getNetworkConn();
       const contract = network.getContract('ChatContract');
        console.log('Submit Chat creation transaction.');
    
        const chatRequestBuffer = await contract.submitTransaction("createChatRequest",room_name,room_id,userId,userName);
        
        let newChatServiceRequest = JSON.parse(chatRequestBuffer.toString());
        console.log(`${newChatServiceRequest.requestId}  successfully created`);
        console.log('Transaction complete.');
        return newChatServiceRequest;
    } catch (error) {
        console.log(`Error processing transaction. ${error}`);
        console.log(error.stack);
        return error.subject;
    } finally {
        // Disconnect from the gateway
        console.log('Disconnect from Fabric gateway.');
        disconnect();
    }
}
}



main("Client1_user1_room", "80056", "user1","Suresh" ).then(() => {

    console.log('ChatRequest created successfully.');

}).catch((e) => {

    console.log('Issue program exception.');
    console.log(e);
    console.log(e.stack);
    process.exit(-1);

});