/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
*/

/*
 * This application has 6 basic steps:
 * 1. Select an identity from a wallet
 * 2. Connect to network gateway
 * 3. Access PaperNet network
 * 4. Construct request to issue commercial paper
 * 5. Submit transaction
 * 6. Process response
 */

'use strict';

// Bring key classes into scope, most importantly Fabric SDK network class
const fs = require('fs');
const yaml = require('js-yaml');
const { getNetwork, disconnect } = require('../util/networkutil');
// Main program function
async function main(room_id,userID,message,timestamp) {

    try {
       //const contract = await getContractInstance();
       const contract = getNetwork().getContract('ChatHistoryContract');
        console.log('Submit Chat history creation transaction.');
    
        const chatHistoryBuffer = await contract.submitTransaction("createChatHistory",room_id,userID,message,timestamp);
        
        let newChatHistory = JSON.parse(chatHistoryBuffer.toString());
        console.log(`${newChatHistory.room_name}  successfully created`);
        console.log('Transaction complete.');
        return newChatHistory;
    } catch (error) {
        console.log(`Error processing transaction. ${error}`);
        console.log(error.stack);
    } finally {
        // Disconnect from the gateway
        console.log('Disconnect from Fabric gateway.');
        disconnect();
    }
}


module.exports = {
    createChatHistory: async function (room_id,userID,message,timestamp) {

        try {
            //const contract = await getContractInstance();
            const contract = getNetwork().getContract('ChatHistoryContract');
             console.log('Submit Chat history creation transaction.');
         
             const chatHistoryBuffer = await contract.submitTransaction("createChatHistory",room_id,userID,message,timestamp);
             
             let newChatHistory = JSON.parse(chatHistoryBuffer.toString());
             console.log(`${newChatHistory.room_name}  successfully created`);
             console.log('Transaction complete.');
             return newChatHistory;
         } catch (error) {
             console.log(`Error processing transaction. ${error}`);
             console.log(error.stack);
         } finally {
             // Disconnect from the gateway
             console.log('Disconnect from Fabric gateway.');
             disconnect();
         }
}
}



main( "80056", "user1","Suresh_chatroom_request",Date.now ).then(() => {

    console.log('ChatHistoryRequest created successfully.');

}).catch((e) => {

    console.log('Issue program exception.');
    console.log(e);
    console.log(e.stack);
    process.exit(-1);

});