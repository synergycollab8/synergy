/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
*/

/*
 * This application has 6 basic steps:
 * 1. Select an identity from a wallet
 * 2. Connect to network gateway
 * 3. Access PaperNet network
 * 4. Construct request to issue commercial paper
 * 5. Submit transaction
 * 6. Process response
 */

'use strict';

// Bring key classes into scope, most importantly Fabric SDK network class
const fs = require('fs');
const yaml = require('js-yaml');
const { getNetworkConn, disconnect } = require('../util/networkutil');
// Main program function
async function main(requestId,request_name,Organisation,status,request_type,createdByUserId,timestamp) {

    try {
        //const contract = await getContractInstance();
        const network = await getNetworkConn();
        const contract = network.getContract('RequestDetailsContract');
         console.log('Submit Request details creation transaction.');
     
         const createRequestDetailsBuffer = await contract.submitTransaction("createRequestDetails",requestId,request_name,Organisation,status,request_type,createdByUserId,timestamp);
         
         let newCreateRequestDetails = JSON.parse(createRequestDetailsBuffer.toString());
         console.log(`${newCreateRequestDetails.requestId}  successfully created`);
         console.log('Transaction complete.');
         return newCreateRequestDetails;
     } catch (error) {
         console.log(`Error processing transaction. ${error}`);
         console.log(error.stack);
         return error.subject;
     } finally {
         // Disconnect from the gateway
         console.log('Disconnect from Fabric gateway.');
         disconnect();
     }
}

module.exports = {
    createRequestDetails: async function (requestId,request_name,Organisation,status,request_type,createdByUserId,timestamp) {

    try {
       //const contract = await getContractInstance();
       const network = await getNetworkConn();
       const contract = network.getContract('RequestDetailsContract');
        console.log('Submit Request details creation transaction.');
    
        const createRequestDetailsBuffer = await contract.submitTransaction("createRequestDetails",requestId,request_name,Organisation,status,request_type,createdByUserId,timestamp);
        
        let newCreateRequestDetails = JSON.parse(createRequestDetailsBuffer.toString());
        console.log(`${newCreateRequestDetails.requestId}  successfully created`);
        console.log('Transaction complete.');
        return newCreateRequestDetails;
    } catch (error) {
        console.log(`Error processing transaction. ${error}`);
        console.log(error.stack);
        return error.subject;
    } finally {
        // Disconnect from the gateway
        console.log('Disconnect from Fabric gateway.');
        disconnect();
    }
}
}



main("12345", "Issue_requestForBG", "BG","Organization<name>","status_pending","issue","Org1UserID",Date.now()).then(() => {

    console.log('RequestDetails created successfully.');

}).catch((e) => {

    console.log('Issue program exception.');
    console.log(e);
    console.log(e.stack);
    process.exit(-1);

}); 
//module.exports = createClientServiceRequest;